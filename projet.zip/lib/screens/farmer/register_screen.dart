import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../widgets/custom_button.dart';
import '../../services/auth_service.dart';
import 'farmer_form_screen.dart';
import 'irrigation_plan_screen.dart';
import '../../presentation/providers/language_provider.dart';

class FarmerRegisterScreen extends ConsumerWidget {
  const FarmerRegisterScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return _FarmerRegisterScreen();
  }
}

class _FarmerRegisterScreen extends ConsumerStatefulWidget {
  const _FarmerRegisterScreen();

  @override
  ConsumerState<_FarmerRegisterScreen> createState() =>
      _FarmerRegisterScreenState();
}

class FarmerLoginScreen extends StatefulWidget {
  const FarmerLoginScreen({super.key});

  @override
  State<FarmerLoginScreen> createState() => _FarmerLoginScreenState();
}

class _FarmerLoginScreenState extends State<FarmerLoginScreen> {
  final _nameController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _loading = false;
  final AuthService _authService = AuthService();

  Future<void> _login() async {
    final name = _nameController.text.trim();
    final password = _passwordController.text.trim();

    if (name.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Veuillez remplir tous les champs'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    setState(() => _loading = true);

    // Utilise le même email technique que pour l’inscription
    final String technicalEmail =
        '${name.toLowerCase().replaceAll(' ', '_')}@farmer.local';

    final result = await _authService.login(
      email: technicalEmail,
      password: password,
    );

    setState(() => _loading = false);

    if (!result['success']) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content:
              Text(result['message']?.toString() ?? 'Identifiants incorrects'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    final user = result['user'];
    if (user.role != 'farmer') {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Seul un compte fermier peut se connecter ici'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Bienvenue 👨‍🌾 Fermier !'),
        backgroundColor: Colors.green,
      ),
    );
    // 🔄 Vérifier sur le backend si le formulaire a déjà été complété
    final profile = await _authService.fetchFarmerProfile();

    final hasCompletedForm =
        profile != null && profile['hasCompletedFarmerForm'] == true;

    if (hasCompletedForm) {
      // Essayer de récupérer les données de parcelle depuis le profil
      final String location = profile['parcelLocation'] as String? ?? '';
      final String soilType = profile['soilType'] as String? ?? 'sableux';
      final List<dynamic> cropsRaw = profile['crops'] as List<dynamic>? ?? [];
      final List<String> cropTypes = cropsRaw.map((e) => e.toString()).toList();

      if (location.isNotEmpty && cropTypes.isNotEmpty) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => IrrigationPlanScreen(
              location: location,
              soilType: soilType,
              cropTypes: cropTypes,
            ),
          ),
        );
        return;
      }
    }

    // Sinon, afficher le formulaire une première fois
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => FarmerFormScreen(farmerName: name),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final primary = theme.colorScheme.primary;

    return Scaffold(
      backgroundColor: const Color(0xFFE8F5E9),
      appBar: AppBar(
        backgroundColor: const Color(0xFF166534),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        centerTitle: true,
        title: const Text(
          'Connexion Fermier',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFC9E4CA), // vert très clair
              Color(0xFFE8F5E9),
            ],
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // En-tête avec icône
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: const Color(0xFFA5D6A7),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: const Color(0xFF43A047),
                          ),
                        ),
                        child: const Icon(
                          Icons.agriculture,
                          color: Color(0xFF1B5E20),
                          size: 32,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'Bienvenue 👨‍🌾',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Color(0xFF1B5E20),
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Connectez-vous pour accéder à votre plan d\'irrigation et à vos données.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.grey.shade600,
                      fontSize: 13,
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Carte de connexion
                  Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF1F8E9),
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(
                        color: const Color(0xFFBDBDBD),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.08),
                          blurRadius: 18,
                          offset: const Offset(0, 10),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        TextField(
                          controller: _nameController,
                          style: const TextStyle(color: Color(0xFF1B5E20)),
                          decoration: InputDecoration(
                            labelText: 'Nom',
                            labelStyle: TextStyle(color: Colors.grey.shade700),
                            prefixIcon: const Icon(
                              Icons.person_outline,
                              color: Color(0xFF388E3C),
                            ),
                            filled: true,
                            fillColor: const Color(0xFFF1F8E9),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(14),
                              borderSide: const BorderSide(
                                color: Color(0xFFBDBDBD),
                              ),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(14),
                              borderSide:
                                  BorderSide(color: primary, width: 1.6),
                            ),
                          ),
                        ),
                        const SizedBox(height: 14),
                        TextField(
                          controller: _passwordController,
                          style: const TextStyle(color: Color(0xFF1B5E20)),
                          decoration: InputDecoration(
                            labelText: 'Mot de passe',
                            labelStyle: TextStyle(color: Colors.grey.shade700),
                            prefixIcon: const Icon(
                              Icons.lock_outline,
                              color: Color(0xFF388E3C),
                            ),
                            filled: true,
                            fillColor: const Color(0xFFF1F8E9),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(14),
                              borderSide: const BorderSide(
                                color: Color(0xFFBDBDBD),
                              ),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(14),
                              borderSide:
                                  BorderSide(color: primary, width: 1.6),
                            ),
                          ),
                          obscureText: true,
                        ),
                        const SizedBox(height: 20),
                        _loading
                            ? const Center(child: CircularProgressIndicator())
                            : CustomButton(
                                text: 'Se connecter',
                                onTap: _login,
                              ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 18),

                  // Lien d'inscription
                  TextButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        PageRouteBuilder(
                          pageBuilder:
                              (context, animation, secondaryAnimation) =>
                                  const FarmerRegisterScreen(),
                          transitionsBuilder:
                              (context, animation, secondaryAnimation, child) {
                            const begin = Offset(0.0, 1.0);
                            const end = Offset.zero;
                            const curve = Curves.easeOutCirc;

                            var tween = Tween(begin: begin, end: end).chain(
                              CurveTween(curve: curve),
                            );

                            return SlideTransition(
                              position: animation.drive(tween),
                              child: FadeTransition(
                                opacity: animation,
                                child: child,
                              ),
                            );
                          },
                          transitionDuration: const Duration(milliseconds: 800),
                        ),
                      );
                    },
                    child: const Text(
                      "S'inscrire comme fermier",
                      style: TextStyle(
                        color: Color(0xFF2E7D32),
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _FarmerRegisterScreenState extends ConsumerState<_FarmerRegisterScreen> {
  final _name = TextEditingController();
  final _password = TextEditingController();
  bool _loading = false;
  final AuthService _authService = AuthService();
  late String currentLang;

  void _showSnackbar(String text, {bool error = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(text),
        backgroundColor: error ? Colors.red : Colors.green));
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Récupérer la langue actuelle
    final locale = ref.watch(languageProvider);
    currentLang = locale.languageCode;
  }

  Future<void> _onRegister() async {
    print('=== _onRegister appelé ===');
    setState(() => _loading = true);

    final String name = _name.text.trim();
    final String password = _password.text.trim();

    print('Nom: "$name", Password: "$password"');

    if (name.isEmpty || password.isEmpty) {
      print('Champs vides!');
      _showSnackbar('Veuillez remplir tous les champs', error: true);
      setState(() => _loading = false);
      return;
    }

    // Génère un email technique à partir du nom, car l'API backend demande un email
    final String technicalEmail =
        '${name.toLowerCase().replaceAll(' ', '_')}@farmer.local';

    print('Email technique: $technicalEmail');

    try {
      final result = await _authService.register(
        name: name,
        email: technicalEmail,
        password: password,
        role: 'farmer',
      );

      print('Résultat register: $result');
      setState(() => _loading = false);

      if (!result['success']) {
        print('Échec inscription: ${result['message']}');
        _showSnackbar(result['message']?.toString() ?? 'Erreur inscription',
            error: true);
        return;
      }

      print('Inscription réussie!');
      _showSnackbar('Compte créé avec succès !');

      // Navigation directe vers le formulaire de parcelle
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => FarmerFormScreen(farmerName: name),
        ),
      );
    } catch (e) {
      print('Exception lors de l\'inscription: $e');
      setState(() => _loading = false);
      _showSnackbar('Erreur technique: $e', error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final primary = theme.colorScheme.primary;

    // Textes localisés
    final Map<String, String> registerTexts = {
      'fr': {
        'createAccount': 'Créer un compte Fermier',
        'description': 'Rejoignez notre communauté de fermiers',
        'name': 'Nom complet',
        'password': 'Mot de passe',
        'register': 'S\'inscrire',
      },
      'en': {
        'createAccount': 'Create Farmer Account',
        'description': 'Join our farming community',
        'name': 'Full Name',
        'password': 'Password',
        'register': 'Register',
      },
      'ar': {
        'createAccount': 'إنشاء حساب مزارع',
        'description': 'انضم إلى مجتمع المزارعين لدينا',
        'name': 'الاسم الكامل',
        'password': 'كلمة المرور',
        'register': 'تسجيل',
      },
    }[currentLang]!;

    return Scaffold(
      backgroundColor: const Color(0xFFE8F5E9),
      appBar: AppBar(
        backgroundColor: const Color(0xFF166534),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        centerTitle: true,
        title: const Text(
          'Créer un compte Fermier',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      body: Directionality(
        textDirection:
            currentLang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
        child: Stack(
          children: [
            // Image de fond avec assombrissement
            Positioned.fill(
              child: ColorFiltered(
                colorFilter: ColorFilter.mode(
                  Colors.black.withOpacity(0.3),
                  BlendMode.darken,
                ),
                child: Image.asset(
                  'assets/images/ferme.png',
                  fit: BoxFit.cover,
                ),
              ),
            ),
            // Contenu par-dessus
            Center(
              child: SingleChildScrollView(
                padding:
                    const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 420),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.9),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                color: const Color(0xFF43A047),
                              ),
                            ),
                            child: const Icon(
                              Icons.agriculture,
                              color: Color(0xFF1B5E20),
                              size: 32,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Text(
                        registerTexts['createAccount']!,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          shadows: [
                            Shadow(
                              color: Colors.black,
                              blurRadius: 4,
                              offset: Offset(1, 1),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        registerTexts['description']!,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Colors.white70,
                          fontSize: 13,
                          shadows: [
                            Shadow(
                              color: Colors.black,
                              blurRadius: 2,
                              offset: Offset(1, 1),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),
                      Container(
                        padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.85),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(
                            color: const Color(0xFFBDBDBD).withOpacity(0.5),
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.15),
                              blurRadius: 18,
                              offset: const Offset(0, 10),
                            ),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            TextField(
                              controller: _name,
                              style: const TextStyle(color: Color(0xFF1B5E20)),
                              decoration: InputDecoration(
                                labelText: registerTexts['name']!,
                                labelStyle:
                                    TextStyle(color: Colors.grey.shade700),
                                prefixIcon: const Icon(
                                  Icons.person_outline,
                                  color: Color(0xFF388E3C),
                                ),
                                filled: true,
                                fillColor: const Color(0xFFF1F8E9),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(14),
                                  borderSide: const BorderSide(
                                    color: Color(0xFFBDBDBD),
                                  ),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(14),
                                  borderSide:
                                      BorderSide(color: primary, width: 1.6),
                                ),
                              ),
                            ),
                            const SizedBox(height: 14),
                            TextField(
                              controller: _password,
                              style: const TextStyle(color: Color(0xFF1B5E20)),
                              decoration: InputDecoration(
                                labelText: registerTexts['password']!,
                                labelStyle:
                                    TextStyle(color: Colors.grey.shade700),
                                prefixIcon: const Icon(
                                  Icons.lock_outline,
                                  color: Color(0xFF388E3C),
                                ),
                                filled: true,
                                fillColor: const Color(0xFFF1F8E9),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(14),
                                  borderSide: const BorderSide(
                                    color: Color(0xFFBDBDBD),
                                  ),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(14),
                                  borderSide:
                                      BorderSide(color: primary, width: 1.6),
                                ),
                              ),
                              obscureText: true,
                            ),
                            const SizedBox(height: 20),
                            _loading
                                ? const Center(
                                    child: CircularProgressIndicator())
                                : CustomButton(
                                    text: registerTexts['register']!,
                                    onTap: _onRegister,
                                  ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
